#include <stdio.h>
#include <string.h>

#define DESLOCAMENTO 3 
#define ARQUIVO "dados.txt" 

void criptografar(char *texto, char *resultado) {
    int i;
    for (i = 0; i < strlen(texto); i++) {
        resultado[i] = texto[i] + DESLOCAMENTO; 
    }
    resultado[i] = '\0'; 
}

void descriptografar(char *texto, char *resultado) {
    int i;
    for (i = 0; i < strlen(texto); i++) {
        resultado[i] = texto[i] - DESLOCAMENTO; 
    }
    resultado[i] = '\0'; 
}

void salvar_dados(char *user, char *senha) {
    FILE *file = fopen(ARQUIVO, "a"); 
    if (file == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        return;
    }
    fprintf(file, "%s %s\n", user, senha); 
    fclose(file); 
}

int verificar_login(char *user, char *senha) {
    char user_c[100], senha_c[100];
    criptografar(user, user_c);
    criptografar(senha, senha_c);

    FILE *file = fopen(ARQUIVO, "r"); 
    if (file == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        return 0;
    }

    char user_file[100], senha_file[100];
    while (fscanf(file, "%s %s", user_file, senha_file) != EOF) {
        if (strcmp(user_c, user_file) == 0 && strcmp(senha_c, senha_file) == 0) {
            fclose(file);
            return 1; 
        }
    }
    fclose(file);
    return 0; 
}

int possui_espacos(char *texto) {
    for (int i = 0; i < strlen(texto); i++) {
        if (texto[i] == ' ') {
            return 1; 
        }
    }
    return 0; 
}

void excluir_usuario(char *user, char *senha) {
    char user_c[100], senha_c[100];
    criptografar(user, user_c);
    criptografar(senha, senha_c);

    FILE *file = fopen(ARQUIVO, "r");
    if (file == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        return;
    }

    FILE *temp_file = fopen("temp.txt", "w");
    if (temp_file == NULL) {
        printf("Erro ao criar arquivo temporario!\n");
        fclose(file);
        return;
    }

    char user_file[100], senha_file[100];
    int found = 0;

    while (fscanf(file, "%s %s", user_file, senha_file) != EOF) {
        if (strcmp(user_c, user_file) == 0 && strcmp(senha_c, senha_file) == 0) {
            found = 1; 
            printf("Usuario %s excluido com sucesso.\n", user);
            continue; 
        }
        fprintf(temp_file, "%s %s\n", user_file, senha_file); 
    }

    fclose(file);
    fclose(temp_file);

    if (found) {
        remove(ARQUIVO); 
        rename("temp.txt", ARQUIVO); 
    } else {
        printf("Usuario nao encontrado.\n");
        remove("temp.txt"); 
    }
}

void listar_usuarios() {
    FILE *file = fopen(ARQUIVO, "r");
    if (file == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        return;
    }

    char user_file[100], senha_file[100];
    printf("Usuarios cadastrados:\n");
    while (fscanf(file, "%s %s", user_file, senha_file) != EOF) {
        char user_desc[100];
        descriptografar(user_file, user_desc);
        printf("- %s\n", user_desc); 
    }

    fclose(file);
}

int main() {
    int escolha;
    char user[100], senha[100];

    while (1) {
        printf("Menu:\n");
        printf("1. Cadastrar\n");
        printf("2. Fazer Login\n");
        printf("3. Excluir Conta\n");
        printf("4. Listar Usuarios\n");
        printf("5. Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &escolha);
        getchar(); 

        switch (escolha) {
            case 1: 
                while (1) {
                    printf("Escreva seu username (sem espa�os): ");
                    fgets(user, sizeof(user), stdin);
                    user[strcspn(user, "\n")] = '\0'; 
                    if (possui_espacos(user)) {
                        printf("O nome de usuario n�o pode conter espa�os. Tente novamente.\n");
                    } else {
                        break; 
                    }
                }

                while (1) {
                    printf("Escreva sua senha (sem espa�os): ");
                    fgets(senha, sizeof(senha), stdin);
                    senha[strcspn(senha, "\n")] = '\0'; 
                    
                    if (possui_espacos(senha)) {
                        printf("A senha nao pode conter espa�os. Tente novamente.\n");
                    } else {
                        break; 
                    }
                }

                char user_c[100], senha_c[100];
                criptografar(user, user_c);
                criptografar(senha, senha_c);

                salvar_dados(user_c, senha_c);
                printf("Dados criptografados salvos com sucesso!\n");
                break;

            case 2: 
                printf("Tente fazer login.\n");
                printf("Username: ");
                scanf("%s", user);
                printf("Senha: ");
                scanf("%s", senha);

                if (verificar_login(user, senha)) {
                    printf("Login bem-sucedido!\n");
                } else {
                    printf("Login falhou. Verifique suas credenciais.\n");
                }
                break;

            case 3: 
                while (1) {
                    printf("Escreva seu username para exclusao (sem espacos): ");
                    fgets(user, sizeof(user), stdin);
                    user[strcspn(user, "\n")] = '\0'; 
                    
                    if (possui_espacos(user)) {
                        printf("O nome de usuario n�o pode conter espacos. Tente novamente.\n");
                    } else {
                        break; 
                    }
                }

                while (1) {
                    printf("Escreva sua senha para exclusao (sem espacos): ");
                    fgets(senha, sizeof(senha), stdin);
                    senha[strcspn(senha, "\n")] = '\0'; 
                    
                    if (possui_espacos(senha)) {
                        printf("A senha nao pode conter espacos. Tente novamente.\n");
                    } else {
                        break; 
                    }
                }

                excluir_usuario(user, senha);
                break;

            case 4: 
                listar_usuarios();
                break;

            case 5: 
                printf("Saindo...\n");
                return 0;

            default:
                printf("Opcao invalida. Tente novamente.\n");
        }
    }

    return 0;
}
